package com.jfource.pppoe;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(Color.WHITE);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setPadding(28, 20, 28, 20);
        return t;
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 36, 20, 20);
        root.setBackgroundColor(Color.rgb(18,18,18));

        TextView title = text("JFOURCE I.T. SOLUTIONS", 25, true);
        title.setTextColor(Color.rgb(220, 30, 40));
        root.addView(title);
        TextView sub = text("PPPoE Billing & Management • Demo", 15, false);
        root.addView(sub);

        String[] cards = {
            "DASHBOARD\nCustomers: 128   Online: 94   Overdue: 7",
            "PPPoE CLIENTS\nManage usernames, plans, due dates and status",
            "BILLING & PAYMENTS\nCash • Wallet • Partial payments • Receipts",
            "WALLET / PREPAID\nBalance tracking and payment history",
            "MIKROTIK\nRouter connection and PPPoE profile control",
            "SMS / EMAIL\nBilling reminders and payment confirmations",
            "STAFF & USERS\nSuper Admin and configurable permissions",
            "REPORTS & SETTINGS\nCollections, revenue, audit log and system settings"
        };
        for (String s : cards) {
            TextView card = text(s, 16, true);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setBackgroundColor(Color.rgb(35,35,35));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, 7, 0, 7);
            root.addView(card, lp);
        }
        setContentView(root);
    }
}
