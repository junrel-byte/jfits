# JFOURCE PPPoE Android Sample

UI-only demo for the JFOURCE I.T. SOLUTIONS PPPoE billing/management app.

This sample does not connect to a MikroTik router or process real billing data.

## Cloud build
GitHub Actions builds the debug APK. Open the **Actions** tab, select **Build JFOURCE APK**, run it manually, then download the `JFOURCE-PPPoE-debug-apk` artifact.
